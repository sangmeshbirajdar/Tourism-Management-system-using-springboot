package com.Spring.demo.entity;

public class Transportation {

}
