package com.Spring.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAndTourismManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelAndTourismManagementSystemApplication.class, args);
		System.out.println("Project Started......");
	}

}
